import React from "react";

function ModalBase({ onClose, layout }) {
    return (
      // 배경 어둡게 처리 (오버레이)
      <div onClick={onClose} className='modal-back'>
        <div
          onClick={(e) => e.stopPropagation()}
          className='modal-boder'
        >
          <div className='modal-header' style={{ }}>
            <h3 style={{ margin: 0, fontSize: '18px' }}>직원 등록</h3>
            <button type="button" onClick={onClose} style={{ cursor: 'pointer', border: 'none', background: 'none', fontSize: '16px' }}>
              ✕
            </button>
          </div>
          
          <div className='modal-body'>
            {layout}
          </div>
  
          <p style={{ fontSize: '14px', color: '#475569' }}>직원 정보를 입력하는 폼이 들어갈 자리입니다.</p>
  
          <div style={{ marginTop: '20px', textAlign: 'right' }}>
            <button type="button" onClick={onClose} className="erp-primary-button">
              닫기
            </button>
          </div>
        </div>
      </div>
    );
  }

export default ModalBase;
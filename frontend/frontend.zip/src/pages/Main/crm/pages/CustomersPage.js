import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import StatisticsCard from '../../../../components/StatisticsCard';

export default function CustomersPage(props) {
  const data = props.data;   // 부모 컴포넌트에서 전달받은 고객 데이터
  const setData = props.setData;   // 고객 데이터를 추가, 수정, 삭제할 때 사용하는 함수

  const navigate = useNavigate();
  const [searchText, setSearchText] = useState('');   // 고객 검색창에 입력한 값을 저장하는 State

  // 이름 또는 연락처에 검색어가 포함된 고객만 찾습니다.
  const filteredCustomers = data.customers.filter(function (customer) {
    const keyword = searchText.trim().toLowerCase();
    const target = (customer.name + ' ' + customer.phone).toLowerCase();
    return target.includes(keyword);
  });

  // 변경: 고정 CSS의 요약 카드에 표시할 고객 수를 실제 데이터에서 계산합니다.
  const customersWithPurchaseIds = new Set(data.purchases.map(function (purchase) {
    return purchase.customerId;
  }));
  const customersWithPurchaseCount = data.customers.filter(function (customer) {
    return customersWithPurchaseIds.has(customer.id);
  }).length;
  const currentMonth = new Date().toLocaleDateString('sv-SE').slice(0, 7);
  const joinedThisMonthCount = data.customers.filter(function (customer) {
    return customer.joinDate && customer.joinDate.slice(0, 7) === currentMonth;
  }).length;

  // 확인을 누른 경우에만 고객과 연결 데이터를 삭제합니다.
  function deleteCustomer(customer) {
    if (!window.confirm('이 고객을 삭제하시겠습니까?')) {
      return;
    }

    const purchaseIds = data.purchases
      .filter(function (purchase) {
        return purchase.customerId === customer.id;
      })
      .map(function (purchase) {
        return purchase.id;
      });

    setData(function (current) {
      return {
        ...current,
        customers: current.customers.filter(function (item) {
          return item.id !== customer.id;
        }),
        purchases: current.purchases.filter(function (item) {
          return item.customerId !== customer.id;
        }),
        consultations: current.consultations.filter(function (item) {
          return item.customerId !== customer.id;
        }),
        claims: current.claims.filter(function (item) {
          return item.customerId !== customer.id && !purchaseIds.includes(item.purchaseId);
        }),
      };
    });
  }

  let emptyMessage = '';
  if (data.customers.length === 0) {
    emptyMessage = '등록된 고객이 없습니다.';
  } else if (filteredCustomers.length === 0) {
    emptyMessage = '검색 결과가 없습니다.';
  }

  return (
    <section className="   ">
      <header className="page-header">
        <div>
          <h1>회원 관리</h1>
        </div>
        <button
          className=""
          onClick={function () { navigate('/main/crm/customers/new'); }}
        >
          고객 등록
        </button>
      </header>

      {/* 변경: 기존 고정 CSS 클래스만 사용해 고객 요약 카드를 추가합니다. */}
      <div className="stats-grid" aria-label="고객 현황">
      <section className="stats-section">
          <StatisticsCard
            title={"회원"}
            count = {data.customers.length}
            stiyle ={"1"}
          />
          <StatisticsCard
            title={"신규회원"}
            count = {"10"}
            stiyle ={"1"}
          />
          <StatisticsCard
            title={"구매이력"}
            count = {"10"}
            stiyle ={"1"}
          />
        </section>
      </div>

      <div className="filter-bar">
        <label className="search-field">
          고객 검색
          <input
            value={searchText}
            onChange={function (event) { setSearchText(event.target.value); }}
            placeholder="이름 또는 연락처 입력"
          />
        </label>
        <span className="result-count">조회 결과 <strong>{filteredCustomers.length}</strong>명</span>
      </div>

      <div className="table-shell">
        <table>
          <thead>
            <tr>
              <th>고객 이름</th>
              <th>연락처</th>
              <th>이메일</th>
              <th>주소</th>
              <th>최근 구매일</th>
              <th>관리</th>
            </tr>
          </thead>
          <tbody>
            {filteredCustomers.map(function (customer) {
              return (
                <tr key={customer.id}>
                  <td className="primary-cell">{customer.name}</td>
                  <td>{customer.phone}</td>
                  <td>{customer.email}</td>
                  <td>{customer.address || '-'}</td>
                  <td>{customer.lastPurchaseDate || '-'}</td>
                  <td className="table-actions">
                    <Link
                      className="table-link-button"
                      to={'/main/crm/customers/edit/' + customer.id}
                    >
                      수정
                    </Link>
                    <button
                      className="danger-button"
                      type="button"
                      onClick={function () { deleteCustomer(customer); }}
                    >
                      삭제
                    </button>
                  </td>
                </tr>
              );
            })}
            {emptyMessage && (
              <tr>
                <td colSpan="6" className="no-data">
                  {emptyMessage}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

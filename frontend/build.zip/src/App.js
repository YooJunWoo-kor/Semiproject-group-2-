import Home from './pages/LoginPage';
import { BrowserRouter, Navigate, Routes, Route } from 'react-router-dom';
import MainApp from './pages/Main/MainApp';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/main/*" element={<MainApp />} />
        <Route path="/login" element={<Navigate to="/" replace />} />
        <Route path="*" element={<Navigate to="/main" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

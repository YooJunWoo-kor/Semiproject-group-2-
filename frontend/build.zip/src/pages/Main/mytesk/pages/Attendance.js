import React from "react";
import ADComp from "../../../../components/ADComp";

function Attendance(){
    return(
        <div>
            <h2>출결관리</h2>

            <ADComp />

            <button type="button">
                수정요청
            </button>
        </div>
    )
}

export default Attendance;